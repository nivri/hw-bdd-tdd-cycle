require 'spec_helper'
require 'rails_helper'

describe MoviesController do
  describe 'finding similar movies' do
    it 'should route properly' do
      expect(:get => "/movies/1/director").
        to route_to(:controller => "movies", :action => "director", :id => "1")
    end
    it 'should call the model method that performs similar movies search' do
      fake_results = [double('movie1'), double('movie2')]
      #expect(Movie).to have_received(:find_movies_by_director).with("1")
      Movie.should_receive(:find_movies_by_director).with('1')  #.and_return(fake_results)
      #get "/movies/1/director"
      post :director, {id: "1"}
    end
    it 'should select the Similar Movies page template for rendering if found movies' do
      fake_results = [double('Movie'), double('Movie')]
      Movie.stub(:find_movies_by_director).with('1').and_return(fake_results)
      post :director, {id: "1"}
      response.should render_template('director')
    end
    it 'should make the Similar Movies results available to that template' do
      fake_results = [double('movie1'), double('movie2')]
      Movie.stub(:find_movies_by_director).with('1').and_return(fake_results)
      post :director, {id: "1"}
      assigns(:movies).should == fake_results
    end
    it 'should select the main page template for rendering if found no movies' do
      fake_results = []
      Movie.stub(:find_movies_by_director).with('1').and_return(fake_results)
      post :director, {id: "1"}
      response.should redirect_to(controller: 'movies', action: 'index')
    end
    it 'should set flash properly if found no movies' do
      fake_results = []
      Movie.stub(:find_movies_by_director).with('1').and_return(fake_results)
      post :director, {id: "1"}
      flash[:notice].should =~ /has no director info/i
    end
  end
  
  describe 'creating movies' do
    it 'should redirect to main page after movie creating' do
      #Movie.stub(:create).with('an argument')
      post :create, {movie: {title: 'Some Title'}}
      response.should redirect_to(controller: 'movies', action: 'index')
    end
    
  end
  
  describe 'deleting movies' do
    it 'should redirect to main page after movie deleting' do
      #Movie.stub(:create).with('an argument')
      delete :destroy, {id: 1}
      response.should redirect_to(controller: 'movies', action: 'index')
    end
    
  end
end
