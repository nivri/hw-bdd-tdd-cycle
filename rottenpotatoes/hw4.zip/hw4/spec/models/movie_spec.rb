require 'spec_helper.rb'
require 'rails_helper'

describe Movie do
  fixtures :movies
  it 'should find movies by the same director' do
    m = Movie.find_movies_by_director(1)
    m.count.should == 2 and
      m.pluck(:title).should include('Star Wars') and
      m.pluck(:title).should include('THX-1138')
  end
 
  it 'should not find movies by different directors' do
    m = Movie.find_movies_by_director(3)
    m.count.should == 1 and
      m.pluck(:title).should include('Blade Runner')
  end
  
  it 'should not find movies by no director' do
    m = Movie.find_movies_by_director(4)
    m.count.should == 0
  end
end