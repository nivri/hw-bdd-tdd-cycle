require 'spec_helper'
require 'rails_helper'

describe MoviesHelper do
  describe 'checking oddness function' do
    it 'should check if even' do
        oddness(0).should == 'even'
    end
    it 'should check if even' do
        oddness(2).should == 'even'
    end
    it 'should check if odd' do
        oddness(1).should == 'odd'
    end
  end
end
    